from bs4 import BeautifulSoup

with open('course.html','r') as html_file:
    content=html_file.read()
    #print(content)
    soup = BeautifulSoup(content, 'lxml')
    #print(soup.prettify())
    '''tags = soup.find('h5')
    print(tags)
    tags1 = soup.find_all('h5')
    print(tags1)
    course_html_tags=soup.find_all('h5')
    for course in course_html_tags:
        print(course.text)'''
    
    course_cards=soup.find_all('div',class_='card')
    for course in course_cards:
        print(course.h5.text)
        print(course.a.text)

